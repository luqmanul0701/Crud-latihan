/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SoalB;
import java.util.Scanner;



/**
 *
 * @author User
 */
public class Plat {
    
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Masukan Nomor Plat");
        int nomorPlat = scanner.nextInt();
        
        if(nomorPlat >= 2000 && nomorPlat <= 6999) {
            System.out.println("Sepeda motor");
        }else{
            System.out.println("Bukan Sepeda Motor");
        }
    }
}
