
package crud;


public class Main {
    public static void main(String[] args) {
        try {
            Form_Siswa from = new Form_Siswa();
            from.setVisible(true);
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
    }
}
