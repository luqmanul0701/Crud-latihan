/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soalA;

/**
 *
 * @author User
 */
public class Banner {
    public static void main(String[] args) {
        System.out.println("N");
        System.out.println("A");
        System.out.println("U");
        System.out.println("F");
        System.out.println("A");
        System.out.println("L");
    }
}
