/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buku;


import java.sql.*;
//import java.util.logging.Level;
//import java.util.logging.Logger;
/**
 *
 * @author User
 */
public class CobaBuku {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/bukudb";
        String username = "root";
        String password = "";
        
        Connection connect;
        try {
            connect = DriverManager.getConnection(url,username, password);
            System.out.println("Koneksi berhasil!");
        } catch (SQLException ex) {
            System.out.println("Koneksi gagal: " + ex);
        }
    }
}
