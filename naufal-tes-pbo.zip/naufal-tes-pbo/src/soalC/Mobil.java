/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soalC;

/**
 *
 * @author User
 */
public class Mobil {
    
    private String id;
    private String nama;
    private String warna;
    private int kecepatan;
    
    public Mobil(String id, String nama, String warna, int kecepatan){
        this.id = id;
        this.nama = nama;
        this.warna = warna;
        this.kecepatan = kecepatan;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public void setKecepatan(int kecepatan) {
        this.kecepatan = kecepatan;
    }

    public String getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public String getWarna() {
        return warna;
    }

    public int getKecepatan() {
        return kecepatan;
    }
    
}
