/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soalC;


/**
 *
 * @author User
 */
public class utama{
    public static void main(String[] args) {
        Mobil[] Mobil  = {
            new Mobil("1234","Santafe","Putih",150),
            new Mobil("4321","Rocky","Merah",100),
            new Mobil("5663","innova ","Hijau",140)
            
            
            
        };
        System.out.println("informasi tentang mobil : ");
        for (Mobil M : Mobil){
            System.out.println("ID : " + M.getId());
            System.out.println("Nama : " + M.getNama());
            System.out.println("Warna : " + M.getWarna());
            System.out.println("Kecepatan : " + M.getKecepatan() + "km/h\n");
        }
}

}
    
